#3.41
def lastF(FirstName, LastName):
    print(LastName + ", " + FirstName[0] + ".")
